//
//  TLRNBridgeModule.h
//  TLReactNativeProject
//
//  Created by lichuanjun on 16/6/27.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"

@interface TLRNBridgeModule : NSObject<RCTBridgeModule>

@end
